package activad1;

import java.util.Scanner;

public class AppPrince {

	 static float largo;
	 static float ancho;
	 static float areametros;
	 static float areamm;
	 static float areakm;
	 static float areacirculo;
	 static float radio;
	 static double pi=3.141592654;
	 
	public static Scanner leerdato =new Scanner(System.in); 
	
	public static void main(String[] args) {
		
		//PEDIR DATOS
		System.out.println("Ingrese largo (metros)");
		largo= leerdato.nextFloat();
		
		System.out.println("ingrese el ancho (metros)");
		ancho = leerdato.nextFloat();
		
		//PROCESO
		areametros= largo*ancho;
		areamm= areametros*1000000;
		areakm= (float) (areamm*Math.pow(10,-6));
		
		radio= (float) (areakm/(2*pi));
		areacirculo= (float) (pi*(radio*radio));
				
		System.out.println("el area en km^2 del circulo es de " +areacirculo);		
		
		
		
		
		
	}

}

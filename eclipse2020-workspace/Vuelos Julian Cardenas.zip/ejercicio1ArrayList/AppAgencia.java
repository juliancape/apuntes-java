package ejercicio1ArrayList;

public class AppAgencia {

	public static void main(String[] args) {
		
		new Agencia("TIQUETES MUY BARATOS . COM", 2).run();
	}
	
}
